﻿using ServerTcp.Services;
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;

namespace ServerTcp
{
    class Program
    {
        static void Main(string[] args)
        {
            IPHostEntry ipHost = Dns.GetHostEntry("localhost");
            IPAddress ipAddr = ipHost.AddressList[0];
            IPEndPoint ipEndPoint = new IPEndPoint(ipAddr, 54321);
            FilmService filmService = new FilmService();
            Socket sListener = new Socket(ipAddr.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            try
            {
                sListener.Bind(ipEndPoint);
                sListener.Listen(10);
                
                while (true)
                {
                    Console.WriteLine("Ожидаем соединение через порт {0}", ipEndPoint);

                    Socket handler = sListener.Accept();
                    string data = null;

                    byte[] bytes = new byte[1024];
                    int bytesRec = handler.Receive(bytes);

                    data += Encoding.UTF8.GetString(bytes, 0, bytesRec);

                    string[] command = data.Split("=");

                    if (String.Equals(command[0], "login"))
                    {
                        filmService.AddUser(command[1]);
                        handler.Send(Encoding.UTF8.GetBytes("Ok"));
                    }

                    if (String.Equals(command[0], "get_users"))
                    {
                       
                        string reply = JsonSerializer.Serialize(filmService.GetUsers());
                        byte[] msg = Encoding.UTF8.GetBytes(reply);
                        handler.Send(msg);
                    }

                    if (String.Equals(command[0], "get_skedule_film"))
                    {
                        string reply = JsonSerializer.Serialize(filmService.GetFilms(command[1]));
                        byte[] msg = Encoding.UTF8.GetBytes(reply);
                        handler.Send(msg);
                    }

                    if (String.Equals(command[0], "get_tiket"))
                    {
                        string reply = JsonSerializer.Serialize(filmService.GetTicket(command[1]));
                        byte[] msg = Encoding.UTF8.GetBytes(reply);
                        handler.Send(msg);
                    }

                    if (String.Equals(command[0], "TheEnd"))
                    {
                        Console.WriteLine("Сервер завершил соединение с клиентом.");
                        break;
                    }

                    handler.Shutdown(SocketShutdown.Both);
                    handler.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                Console.ReadLine();
            }
        }
    }
}
