﻿using ServerTcp.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ServerTcp.Services
{
    public class FilmService
    {
        private List<FilmModel> films = new List<FilmModel>();
        private List<string> users = new List<string>();
        public FilmService()
        {
            CreateFilm();
        }

        public List<FilmModel> GetFilms(string date)
        {
            string[] dateSplit = date.Split('.');
            DateTime dddd = new DateTime(int.Parse(dateSplit[2]), int.Parse(dateSplit[1]), int.Parse(dateSplit[0]));

            List<FilmModel> sortedFilm = films.Where(x => x.Date == dddd).ToList();
            return sortedFilm;
        }

        public void AddUser(string user)
        {
            users.Add(user);
        }

        public List<string> GetUsers()
        {
            return users;
        }

        public string GetTicket(string name)
        {
            string idFilm = films.FirstOrDefault(x => x.Name == name).Id.ToString();
            return idFilm;
        }

        private void CreateFilm()
        {
            films.Add(new FilmModel()
            {
                Id = Guid.NewGuid(),
                Name = "Film 1",
                Date = new DateTime(2020, 3, 10),
                Price = 100
            });
            films.Add(new FilmModel()
            {
                Id = Guid.NewGuid(),
                Name = "Film 2",
                Date = new DateTime(2020, 3, 12),
                Price = 100
            });
            films.Add(new FilmModel()
            {
                Id = Guid.NewGuid(),
                Name = "Film 3",
                Date = new DateTime(2020, 3, 12),
                Price = 100
            });
            films.Add(new FilmModel()
            {
                Id = Guid.NewGuid(),
                Name = "Film 4",
                Date = new DateTime(2020, 3, 10),
                Price = 100
            });
        }
    }
}
