﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ServerTcp.Models
{
    public class FilmModel
    {
        public Guid Id { get; set; }
        public String Name { get; set; }
        public DateTime Date { get; set; }
        public Double Price { get; set; }
    }
}
