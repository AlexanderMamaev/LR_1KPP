﻿using System;
using System.Windows;
using System.Windows.Navigation;

namespace ClientWpf
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

        private void LoginBtn_Click(object sender, RoutedEventArgs e)
        {
            TestService.SendMessage("login=" + textBoxInput.Text);
            MainWindow mWindow = new MainWindow();
            mWindow.Show();
            this.Close();
        }
    }
}
