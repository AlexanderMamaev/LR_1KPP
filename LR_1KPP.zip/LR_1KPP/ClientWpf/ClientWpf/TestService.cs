﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ClientWpf
{
    public static class TestService
    {
        public static string SendMessage(string message)
        {
            try
            {
                return SendMessageFromSocket(54321, message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return ex.ToString();
            }
        }

        static string SendMessageFromSocket(int port, string message)
        {
            byte[] bytes = new byte[1024];

            IPHostEntry ipHost = Dns.GetHostEntry("localhost");
            //IPAddress ipAddr = IPAddress.Any;
            IPAddress ipAddr = ipHost.AddressList[0];
            IPEndPoint ipEndPoint = new IPEndPoint(ipAddr, port);

            Socket sender = new Socket(ipAddr.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            sender.Connect(ipEndPoint);
            byte[] msg = Encoding.UTF8.GetBytes(message);

            int bytesSent = sender.Send(msg);

            int bytesRec = sender.Receive(bytes);

            sender.Shutdown(SocketShutdown.Both);
            sender.Close();

            return Encoding.UTF8.GetString(bytes, 0, bytesRec);
        }
    }
}
