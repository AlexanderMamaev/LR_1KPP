﻿using ClientWpf.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Windows;

namespace ClientWpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void GetFilms_Click(object sender, RoutedEventArgs e)
        {
            string mess = TestService.SendMessage("get_skedule_film=" + (dateInput.SelectedDate.HasValue ? dateInput.SelectedDate.Value.ToString("dd.MM.yyyy") 
                : DateTime.Now.ToString("dd.MM.yyyy")));

            List<FilmModel> films = new List<FilmModel>();
            var ser = new DataContractJsonSerializer(films.GetType());
            var ms = new MemoryStream(Encoding.UTF8.GetBytes(mess));
            List<FilmModel> test = ser.ReadObject(ms) as List<FilmModel>;
            dataGrid.ItemsSource = test;
        }

        private void GetTiket_Click(object sender, RoutedEventArgs e)
        {
            List<ResponseModel> mess = new List<ResponseModel>();
            mess.Add(new ResponseModel(){
                Uuid = TestService.SendMessage("get_tiket=" + textInput.Text) 
            });
            dataGrid.ItemsSource = mess;
        }

        private void GetUser_Click(object sender, RoutedEventArgs e)
        {
            string mess = TestService.SendMessage("get_users=1");
            mess = mess.Replace("\"", string.Empty);
            mess = mess.Replace("\\", string.Empty);
            mess = mess.Replace("[", string.Empty);
            mess = mess.Replace("]", string.Empty);
            List <UserModel> users = new List<UserModel>();

            string[] test = mess.Split(',');
            foreach(string t in test)
            {
                users.Add(new UserModel() { Name = t });
            }
           
            dataGrid.ItemsSource = users;
        }
    }
}
