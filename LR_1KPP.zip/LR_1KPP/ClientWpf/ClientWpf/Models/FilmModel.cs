﻿using System;

namespace ClientWpf.Models
{
    public class FilmModel
    {
        public String Name { get; set; }
        public Double Price { get; set; }
    }
}
