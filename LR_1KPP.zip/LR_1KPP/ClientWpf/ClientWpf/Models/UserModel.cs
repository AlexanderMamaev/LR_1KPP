﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientWpf.Models
{
    public class UserModel
    {
        public string Name { get; set; }
    }
}
